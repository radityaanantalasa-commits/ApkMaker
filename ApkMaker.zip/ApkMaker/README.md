# APK Maker

Paste kode HTML/CSS/JS -> app menghasilkan APK yang bisa diunduh & diinstal.

## Cara pakai
1. Buka folder ini di **Android Studio** (Hedgehog atau lebih baru), tunggu Gradle sync.
2. Run modul `app` ke HP. Gradle otomatis membangun modul `template`
   (cangkang WebView) dan menyalinnya jadi `assets/template.apk`.
3. Di app: isi nama, paste kode, tekan **Buat APK**, lalu **Install APK**.
   File juga tersimpan di folder Downloads.

## Catatan
- Hanya untuk kode web (HTML/CSS/JS). Kode Kotlin/Java tidak bisa dikompilasi di HP.
- Semua APK hasil punya package yang sama (`com.example.generated`),
  jadi menginstal yang baru akan menimpa yang lama.
- `key.p12` (password: `password`) hanya untuk uji coba. Buat sendiri:
  `keytool -genkeypair -alias key -keyalg RSA -keysize 2048 -validity 10000 -storetype PKCS12 -keystore key.p12`
  lalu ganti `PASS` di `ApkBuilder.kt`.
- Saat install pertama, Android minta izin "install dari sumber ini".
