package com.example.apkmaker

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.File
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkBuilder {
    private const val PASS = "password"

    /** Ganti index.html di template, tanda tangani, simpan ke [out]. */
    fun build(ctx: Context, html: String, out: File) {
        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        ZipInputStream(ctx.assets.open("template.apk")).use { zin ->
            ZipOutputStream(unsigned.outputStream().buffered()).use { zout ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.name.startsWith("META-INF/")) continue   // buang tanda tangan lama
                    zout.putNextEntry(ZipEntry(e.name))
                    if (e.name == "assets/www/index.html") zout.write(html.toByteArray())
                    else zin.copyTo(zout)
                    zout.closeEntry()
                }
            }
        }
        sign(ctx, unsigned, out)
        unsigned.delete()
    }

    private fun sign(ctx: Context, input: File, output: File) {
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("key.p12").use { ks.load(it, PASS.toCharArray()) }
        val key = ks.getKey("key", PASS.toCharArray()) as PrivateKey
        val cert = ks.getCertificate("key") as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("key", key, listOf(cert)).build()
        if (output.exists()) output.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input).setOutputApk(output)
            .setV1SigningEnabled(true).setV2SigningEnabled(true)
            .build().sign()
    }
}
