plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.generated"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.generated"
        minSdk = 26
        targetSdk = 29   // 29 supaya resources.arsc boleh dikompres ulang
        versionCode = 1; versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
