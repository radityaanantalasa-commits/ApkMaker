plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.apkmaker"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.apkmaker"
        minSdk = 26; targetSdk = 34
        versionCode = 1; versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
    sourceSets["main"].assets.srcDir(layout.buildDirectory.dir("generated/template"))
}
dependencies { implementation("com.android.tools.build:apksig:8.5.2") }

// Build modul :template lalu salin APK-nya jadi assets/template.apk
val copyTemplate by tasks.registering(Copy::class) {
    dependsOn(":template:assembleDebug")
    from(project(":template").layout.buildDirectory.dir("outputs/apk/debug")) {
        include("*.apk"); rename { "template.apk" }
    }
    into(layout.buildDirectory.dir("generated/template"))
}
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }
    .configureEach { dependsOn(copyTemplate) }
