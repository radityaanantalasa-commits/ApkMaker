package com.example.apkmaker

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var lastUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val title = TextView(this).apply {
            text = "APK Maker"; textSize = 24f; setTypeface(null, Typeface.BOLD)
        }
        val name = EditText(this).apply { hint = "Nama file (tanpa .apk)"; setText("myapp"); setSingleLine() }
        val code = EditText(this).apply {
            hint = "Paste kode HTML/CSS/JS di sini"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            gravity = Gravity.TOP; typeface = Typeface.MONOSPACE; textSize = 13f
        }
        val status = TextView(this)
        val build = Button(this).apply { text = "Buat APK" }
        val install = Button(this).apply { text = "Install APK"; isEnabled = false }

        build.setOnClickListener {
            val html = code.text.toString()
            if (html.isBlank()) { status.text = "Kode masih kosong."; return@setOnClickListener }
            val fileName = name.text.toString().trim().ifEmpty { "myapp" } + ".apk"
            status.text = "Membuat APK..."; build.isEnabled = false
            thread {
                try {
                    val tmp = File(cacheDir, "out.apk")
                    ApkBuilder.build(this, html, tmp)
                    val uri = saveToDownloads(tmp, fileName)
                    runOnUiThread {
                        lastUri = uri; install.isEnabled = true
                        status.text = "Selesai! Tersimpan di Downloads/$fileName"
                    }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Gagal: ${e.message}" }
                } finally { runOnUiThread { build.isEnabled = true } }
            }
        }
        install.setOnClickListener {
            lastUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(it, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad)
            addView(title); addView(name)
            addView(code, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(status); addView(build); addView(install)
        }
        setContentView(root)
    }

    private fun saveToDownloads(src: File, fileName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        return uri
    }
}
